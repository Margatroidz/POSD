#include "Media.h"

Media :: Media()
{
}

Media :: ~Media()
{
}
