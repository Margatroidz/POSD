#ifndef SHAPES_H_INCLUDED
#define SHAPES_H_INCLUDED
#include "Shape.h"
#include "Circle.h"
#include "Rectangle.h"
#include "Triangle.h"
#endif // SHAPES_H_INCLUDED
